


import myfadedpagelib as t
t.setup()



class MyDefinition:
    def __init__(self, x):
        self.x= x
        import myparagraphkey as t
        self.k= t.MyParagraphKey(x)
        import myspeaker as t
        if len(x.date)>0:
            self.date= x.date[-1]
        else:
            self.date= 'None'
        self.img= []
        self.speaker= t.speakers(self, x.speech)
        #from myblocklib import MyBlock
        #s= '\n'.join(x.speech)
        #s= MyBlock(s).myrecord()
        #from myspeech import MySpeech
        #self.speech= MySpeech(s)
    def speechstr(self):
        v= [str(v) for v in self.speaker]
        return '<BR>'.join(v)
    def __eq__(self,obj): return self.k==obj.k
    def __lt__(self,obj): return self.k<obj.k
    def __hash__(self): return hash(self.k)
    def myrows(self):
        import mytags as Tag
        s1= 'Book'
        c1= 'c s2em fArial bg2001FuchsiaRose'
        s4= '%s' % self.speechstr()
        c4= 'c s2em fTNR bgReadingOrange'
        s5= self.date
        c5= 'c s2em fVerdana'
        def f(x, c):
            x= Tag.Td(x)
            x.c= c
            return x
        s1= f(s1,c1)
        s4= f(s4,c4)
        s4.colspan=2
        s5= f(s5,c5)
        s= [s1,s5]
        yield Tag.Tr(s)
        yield Tag.Tr([s4])



if __name__=='__main__':
    xs= []
    a= []
    import myparagraphexport as t
    e= t.MyExport.get()
    for v in e.xs:
        s= v.speechstr()
        print(s)
    print (e)
    from myshow import MyShow
    x= MyShow(e.cx)
    from myhtml import MyHTML
    MyHTML(x).show()

