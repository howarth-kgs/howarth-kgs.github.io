


import myfadedpagelib as t
t.setup()


class MyValue:
    def __init__(self, r):
        self.r= r
        m= r.get
        self.mytype= m('Type')
        if not 'Paragraph' in self.mytype:
            raise ValueError
        v= r['d=']
        if len(v)==0: v= ['None']
        self.date= v
        self.speech= r['::']
        self.book= m('Book')
    def __str__(self):
        ret= [ 'Type %s' % self.mytype ]
        ret+= [ 'Book %s' % self.book ]
        v= ' '.join(self.speech)
        ret+= ['Speech %s' % v]
        ret+= [self.date[-1]]
        return '\n'.join(ret)

