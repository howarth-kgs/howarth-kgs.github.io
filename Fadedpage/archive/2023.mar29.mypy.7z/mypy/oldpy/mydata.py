

import mylib
mylib.setup()

from myfilelib_mydir import MyDir
from myrecordlib_mytable import MyTable

def filter_Type(t):
    for x in t:
        v= x.get('Type')
        b= 'BOOK' in v
        if b: yield x

class MyFiles:
    i= None
    def get():
        c= __class__
        if c.i==None: c.i= c()
        return c.i
    def __init__(self):
        d= '/storage/emulated/0/Download/prose/mylog/data/dictionary/Fadedpage'
        self.homedir= MyDir(d)
        self.checkeddir= MyDir('%s/checked' % d)
        self.d1= MyDir('%s/checked/01' % d)
        self.d2= MyDir('%s/checked/02' % d)
        self.d3= MyDir('%s/checked/03' % d)
        self.d4= MyDir('%s/checked/04' % d)
        self.deb= MyDir('%s/checked/enidblyton' % d)
        self.dnd= MyDir('%s/checked/nancydrew' % d)
        self.show= self.homedir.touch('show.html')
        def get(d):
            e= d.gettype('BOOK')
            yield list(e)
        a= [self.d1, self.d2, self.d3, self.d4]
        a+= [self.deb, self.dnd]
        a+= [self.checkeddir]
        r= []
        for d in a:
            for vx in get(d):
                r+= vx
        self.r= list(filter_Type(r))

if __name__=="__main__":
    x= MyFiles.get()
    for v in x.r:
        print(v)

