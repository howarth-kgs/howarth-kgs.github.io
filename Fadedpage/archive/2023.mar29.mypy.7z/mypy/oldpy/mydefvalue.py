


import mylib
mylib.setup()



class MyValue:
    def _get():
        from myfpbdata import MyFiles
        for r in MyFiles.get().r:
            try:
                yield __class__(r)
            except Exception as e:
                s= '%s' % e
                if len(s)>1:
                    print (s)
                #print (r.get('Type'))
                pass
    def __init__(self,r):
        self.r= r
        m= r.get
        self.mytype= m('Type')
        if not 'BOOK' in self.mytype:
            raise ValueError
        self.name= m('Title')
        self.fabt= r['for-author-by-title']
        self.authorkey= m('AuthorKey')
        self.author= m('Author')
        self.myid= m('#')
        self.pages= m('Pages')
        self.zero= m('0', ' <BR> ')
        self.one= m('Description', ' <BR> ')
        self.two= m('2', ' <BR> ')
        self.three= m('3', ' <BR> ')
        self.four= m('4', ' <BR> ')
        self.category= m('Tags')
        self.dfp= m('Date-first-posted')
        self.dlu= m('Date-last-updated')
        self.dob= m('Date-of-first-publication')
        s= 'https://www.fadedpage.com/showbook.php?pid=%s'
        self.url= s % self.myid
        try:
            self.date= r['d='][-1]
        except:
            print ('date Error')
            print (r)
            raise ValueError
        self.t= (self.url,self.category,self.name)
    def __repr__(self):
        return 'MyValue \n%s' % self
    def __str__(self):
        a= ['Name %s' % self.name]
        a+= ['Category %s' % self.category]
        a+= ['One %s' % self.one]
        a+= ['Date %s' % self.date]
        a+= ['Url %s' % self.url]
        return '\n'.join(a)
    def __eq__(self,obj):
        return self.t==obj.t
    def __lt__(self,obj):
        return self.t<obj.t



if __name__=='__main__':
    xs= MyValue._get()
    for x in xs:
        from urllib.parse import urlparse
        n= urlparse(x.url)[1]
        print (x.name)
