


import myfadedpagelib as t
t.setup()



class MyExport:
    i= None
    def get():
        print ('---fadedpage.myprojectdef.exp.get()---')
        c= __class__
        if c.i==None: c.i= c()
        return c.i
    def __len__(self): return len(self.xs)
    def __str__(self): return str(self.xs)
    def __init__(self):
        self.xs= list(MyDefinition.get())
    def show2(self):
        import mystructuredef as t
        d= t.MyExport.get().name
        import myshow as t
        s= t.MyShow('readingstatus.html',self.xs,d,'home')
        s.getrow= lambda x: x.myrow2()
        s.mysettitle= 'Items'
        s.header= '# Item Saved'
        import myhtml as t
        t.MyHTML([s]).show()
    def show(self):
        import mystructuredef as t
        d= t.MyExport.get().name
        import myshow as t
        s= t.MyShow('myprojectdef.html',self.xs,d,'home')
        s.header= '# Item Saved'
        import myhtml as t
        t.MyHTML([s]).show()



class MyDefinition:
    def get():
        print ('---fadedpage.myprojectdef.def.get()---')
        import myprojectvalue as t
        e= t.MyExport.get()
        for x in e.xs:
            yield __class__(x)
    def __init__(self,x):
        self.x= x
        self.mytype= x.mytype
        import mydt as t
        self.date= t.s2dt(x.date) 
        self.myid= x.myid
        self.title= x.title
        self.checked= x.checked
        def get(d):
            def f(x):
                b= len(x)>4
                b= b and x[-4:]=='.log'
                return b
            for r in d.getrecords(f):
                if len(r.get('Type'))>0:
                    yield r
        from myfilelib_mydir import MyDir
        rx= get(MyDir(x.checked))
        d= {}
        for r in rx:
            k= r.get('Type').split(' ')[0]
            if not k in d.keys():
                d[k]= []
            d[k].append(r)
        k= 'Illustration'
        if not k in d:
            d[k]= []
        self.xs= d
        px= []
        for r in self.xs['Paragraph']:
            r['Book']= self.title
            import myparagraphvalue as t
            x= t.MyValue(r)
            import myparagraphdef as t
            x= t.MyDefinition(x)
            px.append(x)
        px= sorted(px)
        self.px= px
        self.k= { x.k : x for x in px }
        for r in self.xs['Illustration']:
            r['Book']= self.title
            import myillustrationvalue as t
            x= t.MyValue(r)
            import myillustrationdef as t
            try:
                x= t.MyDefinition(x)
            except:
                print ('Illustration error')
                print (x)
                continue
            self.k[x.k].img.append(x)
        import text as t
        a= [t.Text(x) for x in px]
        for x,y in zip(a[:-1],a[1:]):
            if y.v=='<BR>':
                x.v+= y.v
                y.v= ''
        sx= []
        for x in px:
            sx+= x.speaker
        #print ([v.myid for v in sx])
        cx= []
        import myconversation as t
        c= t.MyConversation()
        c.mytype= self.mytype
        for v in sx:
            c.xs.append(v)
            if v.cf:
                cx.append(c)
                c= t.MyConversation()
        if len(c)>0:
            cx.append(c)
        self.cx= cx
    def __repr__(self): return '%s' % self
    def __str__(self):
        a= ['Type %s' % self.mytype]
        a+= ['Date %s' % self.date]
        a+= ['Myid %s' % self.myid]
        a+= ['Title %s' % self.title]
        a+= ['checked %s' % self.checked]
        s= ['%s %d' % (k,len(v)) for k,v in self.xs.items()]
        N= len(self.xs)
        s= [(i+1,N,x) for i,x in enumerate(s)]
        s= ['(%d/%d) %s' % t for t in s]
        a+= s
        a+= ['Paragraphs %d' % len(self.px)]
        return '\n'.join(a)
    def __eq__(self,obj):
        return self.myid==obj.myid
    def __lt__(self,obj):
        return self.date>obj.date
    def myrow2(self):
        import mystructuredef as t
        d= t.MyExport.get().name
        import myshow as t
        fn= '%s.html' % self.myid
        s= t.MyShow(fn, self.cx, d, 'html')
        s.header= '# Text Saved'
        s.mysettitle= 'Conversations <BR> from %s' % self.title
        s.getrow= lambda x: x.myrows()
        import myhtml as t
        t.MyHTML([s]).show()
        s1= self.title
        s1= s.mylink(s1,d)
        c1= 'c fSS bg2006SandDollar'
        s2= self.x.date
        c2= 'c fVerdana'
        import mytags as Tag
        def f(x, c):
            x= Tag.Td(x)
            x.c= c
            return x
        s1= f(s1,c1)
        s2= f(s2,c2)
        yield Tag.Tr([s1,s2])
    def myrow(self):
        import mytags as Tag
        s3= self.mytype
        c3= 'c fSS bg2006SandDollar'
        s4= str(self).replace('\n', '<BR>')
        c4= 'c fTNR bgReadingOrange'
        s5= self.date
        c5= 'c fVerdana'
        def f(x, c):
            x= Tag.Td(x)
            x.c= c
            return x
        s3= f(s3,c3)
        s4= f(s4,c4)
        s4.colspan= 2
        s5= f(s5,c5)
        s= [s3,s5]
        yield Tag.Tr(s)
        yield Tag.Tr([s4])



if __name__=='__main__':
    e= MyExport.get()
    print (e)
    e.show()
    e.show2()

