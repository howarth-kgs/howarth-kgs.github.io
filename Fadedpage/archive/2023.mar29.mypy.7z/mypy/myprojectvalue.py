


import myfadedpagelib as t
t.setup()


class MyExport:
    i= None
    def get():
        print ('---fadedpage.myprojectvalue.exp.get()---')
        c= __class__
        if c.i==None: c.i= c()
        return c.i
    def __len__(self): return len(self.xs)
    def __init__(self):
        print ('---fadedpage.myprojectvalue.exp.__init__()---')
        self.xs= list(MyValue.get())
    def show(self):
        import mystructuredef as t
        d= t.MyExport.get().name
        import myshow as t
        s= t.MyShow('myprojectvalue.html',self.xs,d,'home')
        s.header= '# Item Saved'
        import myhtml as t
        t.MyHTML([s]).show()


class MyValue:
    def get():
        import mystructuredef as t
        e= t.MyExport.get()
        d= e.x.name['boot']
        for x in d.mytypes():
            try:
                yield __class__(x)
            except:
                pass
    def __init__(self,r):
        self.r= r
        m= r.get
        self.mytype= m('Type')
        if not 'Project' in self.mytype:
            raise ValueError
        self.myid= self.mytype.split(' ')[-1]
        try:
            self.date= r['d='][-1]
        except:
            print ('date Error')
            print (r)
            raise ValueError
        self.title= m('Title')
        self.checked= m('checked')
    def __repr__(self):
        a= ['Type %s' % self.mytype]
        a+= ['Date %s' % self.date]
        a+= ['Myid %s' % self.myid]
        a+= ['Title %s' % self.title]
        a+= ['checked %s' % self.checked]
        return '\n'.join(a)
    def __eq__(self,obj): return self.date==obj.date
    def __lt__(self,obj): return self.date<obj.date
    def myrow(self):
        import mytags as Tag
        s3= self.mytype
        c3= 'c fSS bg2006SandDollar'
        s4= repr(self).replace('\n','<BR>')
        c4= 'c fTNR bgReadingOrange'
        s5= self.date
        c5= 'c fVerdana'
        def f(x, c):
            x= Tag.Td(x)
            x.c= c
            return x
        s3= f(s3,c3)
        s4= f(s4,c4)
        s4.colspan= 2
        s5= f(s5,c5)
        yield Tag.Tr([s3,s5])
        yield Tag.Tr([s4])



if __name__=='__main__':
    #import mytextlib as t
    #r= t.MyText(myr).myrecord()
    #print (r)
    e= MyExport.get()
    e.show()

