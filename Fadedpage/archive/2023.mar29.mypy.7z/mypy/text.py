
class Text:
    def __init__(self,x):
        k= x.k.shortname
        v= str(x.speaker)
        self.x= x
        self.date= x.date
        self.k, self.v= k,v
    def __str__(self):
        s= '%s %s'
        s= s % (self.k,self.v)
        return s


