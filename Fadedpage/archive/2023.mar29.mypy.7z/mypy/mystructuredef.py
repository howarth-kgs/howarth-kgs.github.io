


import myfadedpagelib as t
t.setup()



class MyExport:
    i= None
    def get():
        print ('---fadedpage.mystructuredef.exp.get()---')
        c= __class__
        if c.i==None: c.i= c()
        return c.i
    def __len__(self): return len(self.x.name)
    def __str__(self): return str(self.x)
    def __init__(self):
        self.x= MyDefinition.get()
        self.name= self.x.name
    def show(self):
        import myshow as t
        s= t.MyShow('mystructuredef.html',[self.x],self.x.name,'home')
        s.header= '# Item Saved'
        import myhtml as t
        t.MyHTML([s]).show()



class MyDefinition:
    def get():
        print ('---fadedpage.mystructuredef.def.get()---')
        import mystructurevalue as t
        e= t.MyExport.get()
        return __class__(e.x)
    def __init__(self,x):
        self.x= x
        self.mytype= x.mytype
        import mydt as t
        self.date= t.s2dt(x.date) 
        a= [v.split(' ') for v in x.xs]
        import myfilelib_mydir as t
        self.name= {k:t.MyDir(v) for k,v in a}
    def __repr__(self): return '%s' % self
    def __str__(self):
        a= ['Type %s' % self.mytype]
        a+= ['Date %s' % self.date]
        s= ['%s %s' % (k,v) for k,v in self.name.items()]
        N= len(self.name)
        s= [(i+1,N,x) for i,x in enumerate(s)]
        s= ['(%d/%d) %s' % t for t in s]
        a+= s
        return '\n'.join(a)
    def __eq__(self,obj):
        return self.x==obj.x
    def __lt__(self,obj):
        return self.x<obj.x
    def myrow(self):
        import mytags as Tag
        N= len(self.name)
        s3= '%s <BR> %d' % (self.mytype,N)
        c3= 'c s2em fSS bg2006SandDollar'
        s= ['%s %s' % (k,v) for k,v in self.name.items()]
        N= len(self.name)
        s= [(i+1,N,x) for i,x in enumerate(s)]
        s= ['(%d/%d) %s' % t for t in s]
        s4= '<BR>'.join(s)
        c4= 'c s2em fTNR bgReadingOrange'
        s5= self.date
        c5= 'c s2em fVerdana'
        def f(x, c):
            x= Tag.Td(x)
            x.c= c
            return x
        s3= f(s3,c3)
        s4= f(s4,c4)
        s4.colspan= 2
        s5= f(s5,c5)
        s= [s3,s5]
        yield Tag.Tr(s)
        yield Tag.Tr([s4])



if __name__=='__main__':
    e= MyExport.get()
    print (e)
    e.show()

