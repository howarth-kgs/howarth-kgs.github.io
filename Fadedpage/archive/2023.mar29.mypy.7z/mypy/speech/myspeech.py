


import mylib
mylib.setup()

# alias 2 value
def a2v(x):
    d= {'\\3k': 'Jo, Bessie, and Fanny'}
    d['\\3k.']= 'Jo, Bessie, and Fanny.'
    d['\\3k.f']= 'Father'
    d['\\3k.m']= 'Mother'
    d['\\3k.fm']= 'Father and Mother'
    d['\\j']= 'Jo'
    d['\\j,']= 'Jo,'
    d['\\jb']= 'Jo and Bessie'
    d['\\b']= 'Bessie'
    d['\\b,']= 'Bessie,'
    d['\\b.']= 'Bessie.'
    d['\\f']= 'Fanny'
    d['\\f,']= 'Fanny,'
    d['\\bf']= 'Bessie and Fanny'
    d['\\w']= 'Mr. Whiskers'
    d['\\w.']= 'Mr. Whiskers.'
    d['\\tft']= 'the Faraway Tree'
    d['\\Tft']= 'The Faraway Tree'
    d['\\tft.']= 'the Faraway Tree.'
    d['\\s']= 'Silky'
    d["\\s's"]= "Silky's"
    d['\\mw']= 'Mr. Watzisname'
    d['\\pbs']= 'Pop Biscuits'
    if x in d.keys():
        return d[x]
    return x

def s2v(s):
    xs= s.split(' ')
    xs= [a2v(v) for v in xs]
    return ' '.join(xs)

class MySpeech:
    def __init__(self, r):
        self.r= r
        m= r.get
        k= 'CONVERSATION_FINISH'
        self.f= k in r.keys()
        r.dropkey(k)
        k= 'SPEAKER'
        d= r.groupbykey(k)
        d= [(a2v(k),a2v(v)) for k,v in d.items()]
        def f(x):
            k1= 'SPEAKER'
            k2= 'CONVERSATION_FINISH'
            a= [k1,k2]
            return not (x.k in a)
        r= r.select(f)
        r= str(r)
        r= r.replace('\n', ' ')
        while '  ' in r:
            r= r.replace('  ', ' ')
        r= r.split(' ')
        r= [a2v(v) for v in r]
        r= ' '.join(r)
        self.s= r
    def __str__(self):
        s= []
        if self.s:
            if self.y:
                s+= ['%s: %s' % (self.y,self.s)]
            else:
                s+= [self.s]
        if self.f:
            s+= ['<BR>']
        s= '\n'.join(s)
        return s
