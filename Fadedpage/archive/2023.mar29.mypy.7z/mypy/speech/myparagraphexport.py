


class MyExport:
    i= None
    def get():
        print ('---myparagraph.MyExport.get()---')
        c= __class__
        if c.i==None:
            import myparagraph as t
            c.i= c(t.MyParagraph.get())
        return c.i
    def __init__(self,xs):
        print ('---myparagraph.MyExport---')
        xs= sorted(xs)
        self.xs= xs
        self.k= { x.k : x for x in xs }
        a= [Text(x) for x in xs]
        for x,y in zip(a[:-1],a[1:]):
            if y.v=='<BR>':
                x.v+= y.v
                y.v= ''
        sx= []
        for x in xs:
            sx+= x.speaker
        print ([v.myid for v in sx])
        cx= []
        import myconversation as t
        c= t.MyConversation()
        for v in sx:
            c.xs.append(v)
            if v.cf:
                cx.append(c)
                c= t.MyConversation()
        if len(c)>0:
            cx.append(c)
        self.cx= cx
    def __str__(self):
        return '%s' % self.k.keys()



class Text:
    def __init__(self,x):
        k= x.k.shortname
        v= str(x.speaker)
        self.x= x
        self.date= x.date
        self.k, self.v= k,v
    def __str__(self):
        s= '%s %s'
        s= s % (self.k,self.v)
        return s


