

import mylib
mylib.setup()


class MyRow:
    def __init__(self, s):
        self.s= s
    def myrow(self):
        import mytags as Tag
        s1= 'Book'
        c1= 'c s2em fArial bg2001FuchsiaRose'
        c2= 'c s2em fVerdana bgReadingPeach'
        c3= 'c s2em fSS bg2006SandDollar'
        s4= '%s' % self.s
        c4= 'c s2em fTNR bgReadingOrange'
        s5= 'date'
        c5= 'c s2em fVerdana'
        def f(x, c):
            x= Tag.Td(x)
            x.c= c
            return x
        s1= f(s1,c1)
        s4= f(s4,c4)
        s4.colspan=2
        s5= f(s5,c5)
        s= [s1,s5]
        yield Tag.Tr(s)
        yield Tag.Tr([s4])

