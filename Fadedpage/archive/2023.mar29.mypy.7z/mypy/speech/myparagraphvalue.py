


import myfadedpagelib as t
t.setup()


class MyParagraphValue:
    def get():
        import myspeechdata as t
        for r in t.MySpeechFiles.get().r:
            yield MyParagraphValue(r)
    def __init__(self, r):
        self.r= r
        m= r.get
        t= m('Type')
        if not 'Paragraph' in t: raise ValueError
        self.t= t
        self.book= m('Book')
        v= r['d=']
        if len(v)==0: v= ['None']
        self.date= v
        self.speech= r['::']
    def __str__(self):
        ret= []
        ret+= [ 'Type %s' % self.t ]
        ret+= [ 'Book %s' % self.book ]
        v= ' '.join(self.speech)
        ret+= ['Speech %s' % v]
        ret+= [self.date[-1]]
        return '\n'.join(ret)

if __name__=='__main__':
    for v in MyParagraphValue.get():
        print (v)

