


import myfadedpagelib as t
t.setup()

from myfilelib_mydir import MyDir
from myrecordlib_mytable import MyTable

def filter_Type(t):
    for x in t:
        v= x.get('Type')
        b= 'Paragraph' in v
        if b: yield x

title= {'20190961': 'The Enchanted Wood (Faraway Tree #1)'}
class MySpeechFiles:
    i= None
    def get():
        c= __class__
        if c.i==None: c.i= c()
        return c.i
    def __init__(self):
        d= '/storage/emulated/0/Download/prose/mylog/data/dictionary/Fadedpage'
        self.homedir= MyDir(d)
        k= '20190961'
        s= '%s/checked/enidblyton/%s'
        self.deb1= (k,MyDir(s % (d,k)))
        self.show= self.homedir.touch('speech.html')
        def get(d):
            def f(x):
                b= len(x)>4
                b= b and x[-4:]=='.log'
                return b
            for r in d.getrecords(f):
                yield r
        a= [self.deb1]
        rx= []
        for k,d in a:
            for r in get(d):
                r['Book']= title[k]
                rx.append(r)
        self.r= list(filter_Type(rx))

if __name__=="__main__":
    x= MySpeechFiles.get()
    for v in x.r:
        print(v)

