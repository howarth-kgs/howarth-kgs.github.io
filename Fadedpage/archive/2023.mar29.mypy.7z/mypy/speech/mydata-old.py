
import mylib
mylib.setup()

from myfilelib_mydir import MyDir
from myrecordlib_mytable import MyTable

def filter_Type(t):
    for x in t.items():
        v= x.get('Type')
        if len(v)>0: yield x
def data(d):
    t= MyTable()
    for x in d.x:
        t+= x.mytable()
    return filter_Type(t)

class MyFiles:
    def __init__(self):
        print ('init MyFiles')
        d0= '/storage/emulated/0/Download/prose/mylog'
        md= MyDir(d0)
        self.show= md.touch('show.html')
        d2= '73'.split(' ')
        self.r= []
        for x in d2:
            d= '%s/%s' % (d0,x)
            d= MyDir(d)
            self.r+= list( data(d) )

class Singleton:
    __i = None
    @staticmethod
    def get():
        if not Singleton.__i: Singleton()
        return Singleton.__i
    def __init__(self):
        print ('init Singleton')
        if Singleton.__i:
            raise Exception ("This is a singleton!")
        else:
            Singleton.__i = MyFiles()

if __name__=="__main__":
    x= Singleton.get()
    for v in x.r:
        print(v)

