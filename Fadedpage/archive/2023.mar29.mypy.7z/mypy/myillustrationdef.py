


import myfadedpagelib as t
t.setup()

def fn2img(v):
    import mystructuredef as t
    name= t.MyExport.get().name
    d= name['img']
    h= '%s/' % name['html'].name
    i= d.touch(v).fullpath
    i= i.replace(h,'')
    import mytags as Tag
    x= Tag.Img(i)
    x.myclass= 'disblo veralibot mla mra w800px'
    return x

class MyDefinition:
    def __init__(self, x):
        self.x= x
        import myillustrationkey as t
        self.k= t.MyKey(x)
        self.date= x.date[-1]
        self.img= fn2img(x.img)
        a= [v.strip() for v in x.caption]
        if len(a)==1:
            a= a[0]
        else:
            a= '<BR>'.join(a)
        self.caption= a
    def __eq__(self,obj): return self.k==obj.k
    def __lt__(self,obj): return self.k<obj.k
    def myrow(self):
        import mytags as Tag
        s1= '%s' % self.img
        if self.caption:
            s1= '%s <BR> %s' % (s1,self.caption)
        print (s1)
        c1= 'c s2em fTNR bgReadingOrange'
        s5= self.date
        c5= 'c s2em fVerdana'
        def f(x, c):
            x= Tag.Td(x)
            x.c= c
            return x
        s1= f(s1,c1)
        s5= f(s5,c5)
        return Tag.Tr([s1,s5])



if __name__=='__main__':
    xs= []
    a= []
    import myparagraphexport as t
    e= t.MyExport.get()
    for v in e.xs:
        s= v.speechstr()
        print(s)
    print (e)
    from myshow import MyShow
    x= MyShow(e.cx)
    from myhtml import MyHTML
    MyHTML(x).show()

