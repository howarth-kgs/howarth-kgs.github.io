


import myfadedpagelib as t
t.setup()


class MyValue:
    def __init__(self, r):
        self.r= r
        m= r.get
        self.mytype= m('Type')
        if not 'Illustration' in self.mytype:
            raise ValueError
        v= r['d=']
        if len(v)==0: v= ['None']
        self.date= v
        self.caption= r['::']
        self.book= m('Book')
        self.img= m('img')
        self.between= m('between')
    def __str__(self):
        ret= [ 'Type %s' % self.mytype ]
        ret+= [ 'Book %s' % self.book ]
        v= '<BR>'.join(self.caption)
        ret+= ['Caption %s' % v]
        ret+= [self.date[-1]]
        ret+= ['img %s' % self.img]
        ret+= ['between %s' % self.between]
        return '\n'.join(ret)

