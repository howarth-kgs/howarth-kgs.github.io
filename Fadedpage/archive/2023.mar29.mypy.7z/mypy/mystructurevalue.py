


import myfadedpagelib as t
t.setup()


class MyExport:
    i= None
    def get():
        print ('---fadedpage.mystructurevalue.exp.get()---')
        c= __class__
        if c.i==None: c.i= c()
        return c.i
    def __len__(self): return len(self.name)
    def __init__(self):
        print ('---fadedpage.mystructurevalue.exp.__init__()---')
        e= list(MyValue.get())
        if not len(e)==1:
            raise ValueError
        self.x= e[0]
        a= [v.split(' ') for v in self.x.xs]
        import myfilelib_mydir as t
        self.name= {k:t.MyDir(v) for k,v in a}
    def show(self):
        import myshow as t
        s= t.MyShow('mystructurevalue.html',[self.x],self.name,'home')
        s.header= '# Item Saved'
        import myhtml as t
        t.MyHTML([s]).show()


class MyValue:
    def get():
        import myfilelib_mydir as t
        d= '/storage/emulated/0/Download/prose/mylog/data/dictionary/Fadedpage/boot'
        f= t.MyDir(d).touch('boot')
        for x in f.mytypes():
            try:
                yield __class__(x)
            except:
                pass
    def __init__(self,r):
        self.r= r
        m= r.get
        self.mytype= m('Type')
        if not 'Structure' in self.mytype:
            raise ValueError
        try:
            self.date= r['d='][-1]
        except:
            print ('date Error')
            print (r)
            raise ValueError
        k= 'Type d='
        k= k.split(' ')
        f= lambda x: not x.k in k
        r= r.select(f)
        self.xs= str(r).split('\n')
    def __repr__(self):
        a= ['Type %s' % self.mytype]
        a+= ['Date %s' % self.date]
        for x in self.xs:
            a+= ['xs %s' % x]
        return '\n'.join(a)
    def __eq__(self,obj): return self.date==obj.date
    def __lt__(self,obj): return self.date<obj.date
    def myrow(self):
        import mytags as Tag
        N= len(self.xs)
        s3= '%s <BR> %d' % (self.mytype,N)
        c3= 'c fSS bg2006SandDollar'
        a= self.xs
        a= ['%d/%d) %s' % (i+1,N,str(x)) for i,x in enumerate(a)]
        s4= '<BR>'.join(a)
        c4= 'c fTNR bgReadingOrange'
        s5= self.date
        c5= 'c fVerdana'
        def f(x, c):
            x= Tag.Td(x)
            x.c= c
            return x
        s3= f(s3,c3)
        s4= f(s4,c4)
        s4.colspan= 2
        s5= f(s5,c5)
        yield Tag.Tr([s3,s5])
        yield Tag.Tr([s4])



if __name__=='__main__':
    #import mytextlib as t
    #r= t.MyText(myr).myrecord()
    #print (r)
    e= MyExport.get()
    e.show()

