


def speakers(p,a):
    ret= [MySpeaker(p)]
    k= 'SPEAKER '
    i= len(k)
    for x in a:
        if x[:i]==k:
            ret.append(MySpeaker(p,x[i:]))
        else:
            ret[-1].append(x)
    if len(ret)==1:
        return ret
    if len(ret)>1 and len(ret[0])==0:
        del ret[0]
    k= 'CONVERSATION_FINISH'
    for v in ret:
        if len(v)>0 and v.xs[-1]==k:
            v.cf= True
            del v.xs[-1]
    return ret



class MySpeaker:
    def __init__(self, p, s= 'None'):
        self.p= p
        self.myid= p.k
        self.date= p.date
        if s[-1] in '.!?,;-:':
            s= list(s)
            del s[-1]
            s= ''.join(s)
        self.speaker= s
        self.xs= []
        self.cf= False
    def __lt__(self,obj):
        return self.myid<obj.myid
    def __eq__(self,obj):
        return self.myid==obj.myid
    def __len__(self): return len(self.xs)
    def append(self,x): self.xs.append(x)
    def __str__(self):
        s1= self.speaker
        s2= ' '.join(self.xs)
        k= self.myid.shortname
        if s2== '': return k
        import myspeech as t
        s1= t.s2v(s1)
        s2= t.s2v(s2)
        return '%s %s: %s' % (k, s1,s2)

