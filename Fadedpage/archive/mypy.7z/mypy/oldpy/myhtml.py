

import mylib
mylib.setup()


class MyHTML:
    def __init__(self,x):
        print ('---myfpbhtml.MyHTML()---')
        self.x= x
        self.x2= None
        from myfpbdata import MyFiles
        self.out= MyFiles.get().homedir.touch(x.fn)
    def table(self, x):
        yield '<table border=1 class="mla mra" width=900px>'
        v= x.mytitle()
        if v: yield v
        v= x.myheader()
        if v: yield v
        for v in x.myrows():
            yield v
        v= x.myfooter()
        if v: yield v
        yield '</table><BR>'
    def html(self):
        from mystyle import MyHead
        yield '''
        <!DOCTYPE html PUBLIC
        "-//W3C//DTD XHTML 1.0 Strict//EN"
        "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
        '''
        yield '<html>'
        yield '%s' % MyHead()
        yield '<body>'
        for v in self.table(self.x):
            yield v
        yield '<BR>'
        if self.x2:
            for v in self.table(self.x2):
                yield v
        yield '</body>'
        yield '</html>'
    def show(self):
        self.out.save('')
        for x in self.html():
            self.out.append(x)

