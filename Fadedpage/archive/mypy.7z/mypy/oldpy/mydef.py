
import mylib
mylib.setup()

class MyExport:
    i= None
    def get():
        print ('---myfpbdef.MyExport.get()---')
        c= __class__
        if c.i==None:
            c.i= c(MyDefinition.get())
        return c.i
    def __init__(self,xs):
        print ('---myfpbdef.MyExport---')
        xs= sorted(xs)
        self.xs= xs
        self.t= { x.t : x for x in xs }
        from myutil import mygroup
        self.name= mygroup(xs, lambda x: x.name)
    def __str__(self):
        return '%s' % self.name.keys()


class MyShow:
    def __init__(self):
        self.fn= 'fadedpage.html'
        self.date= None
        self.xs= MyExport.get().xs
    def mytitle(self):
        import mytags as Tag
        s= '%d Fadedpage Definitions' % len(self.xs)
        c= 'c s2em fSS bg2006SandDollar'
        s= Tag.Td(s,c)
        s.colspan= 5
        return Tag.Tr([s])
    def myheader(self):
        s= '# Netloc Category Name Saved'
        s= s.split(' ')
        import mytags as t
        s= [t.Th(x) for x in s]
        return t.Tr(s)
    def myrows(self):
        import mytags as Tag
        i= 1
        for x in self.xs:
            n= Tag.Td(i)
            n.c= 'c s2em fVerdana bg2000CeruleanBlue'
            for j,y in enumerate(x.myrow2()):
                r= [n] + y.a[-5:]
                r= Tag.Tr(r)
                yield '%s' % r
            i+= 1

class MyGenericShow:
    def __init__(self,n,xs):
        self.fn= 'Fadedpage/%s.html' % n
        self.date= None
        self.xs= xs
        self.title= 'title'
        self.titlecolspan= 1
        self.message= None
    def mylink(self,text):
        import mytags as Tag
        a= Tag.A(str(text),self.fn)
        return '%s' % a
    def mytitle(self):
        import mytags as Tag
        c= 'c s2em fSS bg2006SandDollar'
        s= Tag.Td(self.title,c)
        s.colspan= self.titlecolspan 
        return Tag.Tr([s])
    def myheader(self): return None
    def myfooter(self): return None
    def myrows(self):
        import mytags as Tag
        i= 1
        for x in self.xs:
            n= Tag.Td(i)
            n.c= 'c s2em fVerdana bg2000CeruleanBlue'
            n.rowspan= 2
            for j,y in enumerate(x.myrow()):
                if j==0:
                    r= [n] + y.a
                    r= Tag.Tr(r)
                    yield '%s' % r
                else:
                    yield '%s' % y
            i+= 1



class MyShow2:
    def __init__(self):
        self.fn= 'fadedpage.html'
        self.date= None
        self.xs= MyExport.get().xs
        f= lambda x: x.k
        from myutil import mygroup
        self.d= mygroup(self.xs,f)
        print (self.d.keys())
    def mytitle(self):
        import mytags as Tag
        s= '%d Fadedpage Titles grouped by Hash' % len(self.xs)
        c= 'c s2em fSS bg2006SandDollar'
        s= Tag.Td(s,c)
        s.colspan= 27
        return Tag.Tr([s])
    def myheader(self): return None
    def myfooter(self):
        import mytags as Tag
        s= '%d/%d accounted for'
        s= s % (self.yc,len(self.xs))
        s= Tag.Td(s)
        s.colspan=27
        s.c= 'c s2em fVerdana'
        return Tag.Tr([s])
    def myrows(self):
        import mytags as Tag
        s= 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
        t= s
        s= list(s)
        s= [Tag.Td(x) for x in s]
        for x in s:
            x.c= 'c s2em fVerdana bg2001FuchsiaRose'
        n= Tag.Td('.')
        n.c= 'c s2em fVerdana'
        r= [n]+s
        r= Tag.Tr(r)
        yield '%s' % r
        self.yc= 0
        for x in s:
            a= x.v
            n= Tag.Td(a)
            n.c= 'c s2em fVerdana bg2000CeruleanBlue'
            y= []
            for b in list(t):
                k= [a,b]
                k= ''.join(k).lower()
                m=0
                if k in self.d.keys():
                    xs= self.d[k]
                    print (k)
                    #for v in xs:
                    #    print (v.name)
                    show= MyGenericShow(k,xs)
                    show.title=k
                    show.titlecolspan= 6
                    m= len(xs)
                    self.yc+= m
                    m= show.mylink(m)
                    from myhtml import MyHTML
                    MyHTML(show).show()
                y.append(m)
            y= [Tag.Td(v) for v in y]
            for v in y:
                v.c= 'c s2em fVerdana bgReadingOrange'
            r= [n]+y
            r= Tag.Tr(r)
            yield '%s' % r


def gap(nx):
    prev= 0
    for x in sorted(nx):
        if x-prev > 1:
            yield range(prev+1,x)
        prev= x

class MyShow3:
    def __init__(self):
        self.fn= 'fadedpage.html'
        self.date= None
        self.xs= MyExport.get().xs
        f= lambda x: x.authorkey.lower()
        from myutil import mygroup
        self.d= mygroup(self.xs,f)
        print (self.d.keys())
    def mytitle(self):
        import mytags as Tag
        s= '%d Fadedpage Books grouped by Author' % len(self.xs)
        c= 'c s2em fSS bg2006SandDollar'
        s= Tag.Td(s,c)
        s.colspan= 3
        return Tag.Tr([s])
    def myheader(self): 
        import mytags as Tag
        s= '# Author Count'
        s= s.split(' ')
        h= [Tag.Th(x) for x in s]
        return Tag.Tr(h)
    def myfooter(self):
        import mytags as Tag
        s= '%d/%d accounted for'
        s= s % (self.yc,len(self.xs))
        s= Tag.Td(s)
        s.colspan=27
        s.c= 'c s2em fVerdana'
        return Tag.Tr([s])

    def myrows(self):
        import mytags as Tag
        i0= 0
        self.yc= 0
        for k,v in sorted(self.d.items()):
            f= lambda x: x.fabti
            xs= sorted(v,key= f)
            kc= v[0].authorkey
            s= Tag.Td(kc)
            s.c= 'c s2em fVerdana bg2001FuchsiaRose'
            n= len(v)
            self.yc+= n
            a= 'author_%s' % k.replace(' ','_')
            show= MyGenericShow(a,xs)
            t= ['%d Books by %s' % (n,kc)]
            t+= ['Following numbered titles are missing:']
            g= [w.fabti for w in xs]
            for x in gap(g):
                a,b= x[0],x[-1]
                if a==b:
                    t+= [str(a)]
                else:
                    t+= ['%d-%d' % (a,b)]
            t= '<BR>'.join(t)
            show.title= t
            show.titlecolspan= 6
            from myhtml import MyHTML
            MyHTML(show).show()
            n= show.mylink(n)
            n= Tag.Td(n)
            n.c= 'c s2em fVerdana bgReadingYellow'
            i0+= 1
            i= Tag.Td(i0)
            i.c= 'c s2em fVerdana bg2000CeruleanBlue'
            r= [i,s,n]
            r= Tag.Tr(r)
            yield '%s' % r


class MyLife:
    def __init__(self,x):
        self.myid= x.myid
        self.url= x.url
        self.dob= x.dob
        self.author= x.author
        self.dfp= x.dfp
        self.fabt= x.fabt
    def __str__(self):
        import mytags as Tag
        s0= Tag.A(self.myid,self.url)
        s1= 'Date of First Publication %s' % self.dob
        s2= 'Author %s' % self.author
        s3= 'Date of First Post %s' % self.dfp
        s4= 'For Author By Title %s' % self.fabt
        s= [s0,s1,s2,s3,s4]
        return '<BR>'.join(s)

class MyDefinition:
    def get():
        print ('---myfpbdef.MyDef.get()---')
        from myfpbdata import MyFiles
        for r in MyFiles.get().r:
            try:
                yield __class__(r)
            except Exception as e:
                s= '%s' % e
                if len(s.strip())>0:
                    print (e)
                pass
    def __init__(self,r):
        import myfpbdefvalue as t
        x= t.MyValue(r)
        self.x= x
        self.mytype= x.mytype
        self.myid= x.myid
        if len(x.fabt)==0:
            self.fabt= '1 of 1'
        else:
            self.fabt= x.fabt[0]
        self.fabti= int(self.fabt.split(' ')[0])
        from urllib.parse import urlparse
        self.netloc= urlparse(x.url)[1]
        self.category= x.category
        self.name= x.name
        self.authorkey= x.authorkey
        self.author= x.author
        if not self.authorkey:
            self.authorkey= self.author.split(' ')[0]
        from myutil import bland
        k= bland(self.name).replace("'",'')
        k= k.split(' ')
        w= ['the', 'a', 'complete']
        while k[0] in w:
            k= k[1:]
        k= ' '.join(k)
        k= k.replace(' ','')
        k= [k[0],k[1]]
        self.k= ''.join(k)
        self.date= x.date
        self.url= x.url
        self.dob= x.dob
        self.dfp= x.dfp
        life= '%s' % MyLife(self)
        a= [life,x.zero,x.one,x.two,x.three,x.four]
        a= [v for v in a if v]
        if len(a)>1:
            a= '<BR><BR>'.join(a)
        else:
            a= a[0]
        self.one= a
        s= x.dob[-4:]
        import myutil
        self.t= myutil.s2i(s)
        if isinstance(self.t, int):
            pass
        else:
            print ('%s dob not int %s' % (self.myid,self.t))
            self.t= 0
    def __repr__(self): return '%s' % self
    def __str__(self): return mystr(self)
    def __eq__(self,obj):
        return self.name==obj.name
    def __lt__(self,obj):
        return self.t<obj.t
    def myrow(self):
        import mytags as Tag
        s1= '.'.join(self.netloc.split('.')[1:])
        c1= 'c s2em fArial bg2001FuchsiaRose'
        s2= self.category
        c2= 'c s2em fVerdana bgReadingPeach'
        s3= self.name
        c3= 'c s2em fSS bg2006SandDollar'
        s4= '%s' % self.one
        c4= 'c s2em fTNR bgReadingOrange'
        s5= self.date
        c5= 'c s2em fVerdana'
        def f(x, c):
            x= Tag.Td(x)
            x.c= c
            return x
        s1= f(s1,c1)
        s2= f(s2,c2)
        s3= f(s3,c3)
        s3.colspan=2
        s4= f(s4,c4)
        s4.colspan=5
        s5= f(s5,c5)
        s= [s1,s2,s3,s5]
        yield Tag.Tr(s)
        yield Tag.Tr([s4])
    def myrow2(self): return myrow2(self)

def myrow2(x):
    import mytags as Tag
    s1= '.'.join(x.netloc.split('.')[1:])
    c1= 'c s2em fArial bg2001FuchsiaRose'
    s2= x.k
    c2= 'c s2em fVerdana bgReadingPeach'
    s3= x.name
    c3= 'c s2em fSS bg2006SandDollar'
    s5= x.date
    c5= 'c s2em fVerdana'
    def f(x, c):
        x= Tag.Td(x)
        x.c= c
        return x
    s1= f(s1,c1)
    s2= f(s2,c2)
    s3= f(s3,c3)
    s5= f(s5,c5)
    s= [s1,s2,s3,s5]
    yield Tag.Tr(s)




if __name__=='__main__':
    s=MyExport.get()
    #print (s)
    x= MyShow2()
    from myhtml import MyHTML
    h= MyHTML(x)
    h.x2= MyShow3()
    h.show()
