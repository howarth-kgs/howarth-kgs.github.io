
def rn2i(s):
    if s=='I':
        return 1
    return int(s)

class MyKey:
    def __init__(self, x):
        s= x.between
        if not 'of' in s:
            raise ValueError
        p,c= s.split('of')
        p= p.lower().replace('ch','')
        p= p.strip().split('-')[-1]
        if '(' in p:
            p= p.split('(')[0]
        p= int(p)
        c= c.strip().split('-')[-1]
        c= rn2i(c)
        self.chapter= c
        self.paragraph= p
        self.book= x.book
        self.t= (x.book,c,p)
        self.shortname= '%d.%d' % (c,p)
    def __str__(self):
        s= 'Book %s, Chapter %d, Paragraph %d'
        return s % self.t
    def __repr__(self):
        t= '%d.%d' % (self.chapter,self.paragraph)
        return str(t)
    def __eq__(self,obj): return self.t==obj.t
    def __lt__(self,obj): return self.t<obj.t
    def __hash__(self): return hash(self.t)

if __name__=="__main__":
    s= 'Paragraph 2 of CHAPTER-I'
    b= 'The Enchanted Wood (Faraway Tree #1)'
    x= MyParagraphKey(s,b)
    print (x)

