
import os.path

#private
def add(p,dn):
    #v= os.path.abspath(dn)
    v= '%s/%s' % (p,dn)
    import sys
    if not v in sys.path:
        sys.path.append(v)

d1= '/storage/emulated/0/Download/prose/mylib'
d2= '/storage/emulated/0/Download/prose/mylog/data/dictionary/Fadedpage'
def setup():
    d= d1
    add(d,'.')
    add(d,'myrecord')
    add(d,'myfile')
    add(d,'myblock')
    add(d,'myblackboard')
    add(d,'mytext')
    add(d,'myankinote')
    add(d,'mysite3')
    d= d2
    add(d,'mypy')

'''
cp -i myfadedpagelib.py /data/data/com.termux/files/usr/lib/python3.11/.
'''
