
import myfadedpagelib as t
t.setup()

import myrecordlib as t

import myparagraphvalue as t
xs= t.MyParagraphValue.get()
xs= list(xs)
print (xs[0])
