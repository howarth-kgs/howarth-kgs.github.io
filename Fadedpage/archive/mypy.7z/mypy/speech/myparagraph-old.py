
import mylib
mylib.setup()
import mytaglib as Tag

import traceback
import sys

class MyData:
    def __init__(self,c):
        print ('init MyData (%s) from myparagraph.py' % c)
        self.c= c
        from mydata import Singleton as d
        e= self.get(d.get().r)
        self.xs= sorted(e)
    def __getitem__(self,i):
        return self.xs[i]
    def get(self,e):
        for x in e:
            try: yield self.c(x)
            except Exception as e:
                #print (e,'[',str(x)[:10],']')
                #print (traceback.format_exc())
                #print (sys.exc_info()[2])
                pass
    def __repr__(self):
        ret= [ '{%s}' % x for x in self ]
        ret= ', '.join(ret)
        return 'Scenes %s' % ret
    def __len__(self): return len(self.xs)
    def mytitle(self):
        s1= "Paragraphs from multiple books."
        s2= self.conclusion()
        s= '%s <BR> %s' % (s1,s2)
        s= Tag.H1(s)
        return Tag.MyTitle(s,6)
    def conclusion(self):
        return 'There are %s paragraphs read.' % len(self)
    def myheader(self):
        n1= Tag.H1('Paragraph')
        n2= Tag.H1('Original Text')
        n3= Tag.H1('Date')
        n1= Tag.TrItem('th',n1,1)
        n2= Tag.TrItem('th',n2,1)
        n3= Tag.TrItem('th',n3,1)
        tr= Tag.Tr2([n1,n2,n3])
        return '%s' % tr

    def _get(): return MyData(__class__)
    def _myhtml():
        from myhtml import MyHTML
        return MyHTML(__class__._get())
    def __init__(self, r):
        self.r= r
        m= r.get
        t= m('Type')
        if not 'Original Paragraph' in t:
            raise ValueError
        from myparagraphkey import MyParagraphKey
        book= m('book_key')
        if len(book)==0:
            raise ValueError
        self.paragraph_key= MyParagraphKey(m('paragraph_key'), m('book_key'))
        try:
            self.date= r['d='][-1]
        except:
            raise ValueError
        import myparagraphunaccounted as mpu
        self.unaccounted= mpu.MyParagraphUnaccounted(r)
        xs= 'Type book_key paragraph_key d='.split(' ')
        f= lambda x: not x.k in xs
        r= r.select(f)
        self.text= str(r)
        #print (self.text)
    def __str__(self):
        n= 'Paragraph %s' % self.paragraph_key
        t= repr(self.text)
        d= 'Date %s' % self.date
        xs= [n,t,d]
        return ', '.join(xs)
    def __repr__(self):
        return 'MyParagraph %s' % str(self)
    def __eq__(self,obj):
        return self.paragraph_key==obj.paragraph_key
    def __lt__(self,obj):
        return self.paragraph_key<obj.paragraph_key
    def show(self, s=None):
        from mytaglib import MyValue
        from myheads import bb
        d= {}
        a0= 'p0d'
        a= a0
        s= '%s' % self.paragraph_key
        d['p']= MyValue(s,'c')
        s= '%s' % self.date
        d['d']= MyValue(s,'c')
        for i,x in enumerate([self.text]):
            j= str(i)
            if i>0:
                s= a0.replace('0',j)
                a= '%s\n%s' % (a,s)
            d[j]= MyValue(x,'c')
        return bb(a,d)

if __name__=='__main__':
    c= MyParagraph
    xs= c._get()
    def unaccounted(xs):
        book= 'Red Tower'.split()
        for s in book:
            a= [(x.paragraph_key.chapter,x.paragraph_key.paragraph) for x in xs if s in x.paragraph_key.book and len(x.unaccounted.u)>0]
            yield (s,a)
    for s,x in unaccounted(xs):
        print (s,' '.join(['%s.%s' % (c,p) for c,p in x]))
    c._myhtml().show()

