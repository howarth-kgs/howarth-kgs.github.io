


def rn2i(s):
    if s=='I':
        return 1
    return int(s)
class MyParagraphKey:
    def __init__(self, t,b):
        self.s= t
        print (t)
        p,c= t.split('of')
        p= p.strip()
        p= p.split(' ')[-1]
        p= int(p)
        c= c.strip()
        c= c.split('-')[-1]
        c= rn2i(c)
        self.chapter= c
        self.paragraph= p
        self.book= b
        self.t= (b,c,p)
        self.shortname= '%d.%d' % (c,p)
    def __str__(self):
        s= 'Book %s, Chapter %d, Paragraph %d'
        return s % self.t
    def __repr__(self):
        t= '%d.%d' % (self.chapter,self.paragraph)
        return str(t)
    def __eq__(self,obj): return self.t==obj.t
    def __lt__(self,obj): return self.t<obj.t
    def __hash__(self): return hash(self.t)

if __name__=="__main__":
    s= 'Paragraph 2 of CHAPTER-I'
    b= 'The Enchanted Wood (Faraway Tree #1)'
    x= MyParagraphKey(s,b)
    print (x)

