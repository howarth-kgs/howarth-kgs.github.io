

import mylib
mylib.setup()

class MyShow:
    def __init__(self,xs):
        self.fn= 'conversations.html'
        self.date= None
        self.xs= xs
    def mytitle(self):
        import mytags as Tag
        title= 'The Enchanted Wood (Faraway Tree #1)'
        s= '%d Conversations' % len(self.xs)
        s= '%s from <BR> %s' % (s,title)
        c= 'c s2em fSS bg2006SandDollar'
        s= Tag.Td(s,c)
        s.colspan= 3
        return Tag.Tr([s])
    def myheader(self):
        s= '# Text Saved'
        s= s.split(' ')
        import mytags as t
        s= [t.Th(x) for x in s]
        return t.Tr(s)
    def myfooter(self):
        return ''
    def myrows(self):
        import mytags as Tag
        i= 1
        for x in self.xs:
            n= '%d/%d' % (i,len(self.xs))
            n= Tag.Td(n)
            n.c= 'c s2em fVerdana bg2000CeruleanBlue'
            rx= list(x.myrows())
            n.rowspan= len(rx)
            first= True
            for y in rx:
                if first:
                    r= [n] + y.a
                    r= Tag.Tr(r)
                    first= False
                else:
                    r= y
                yield '%s' % r
            i+= 1

