

class MyConversation:
    def __init__(self):
        self.xs= []
    def mydate(self): return self.xs[-1].date
    def __len__(self): return len(self.xs)
    def __lt__(self,obj):
        return self.xs[0]<obj.xs[0]
    def __eq__(self,obj):
        return self.xs[0]==obj.xs[0]
    def append(self,x): self.xs.append(x)
    def __str__(self):
        s= [str(v) for v in self.xs]
        s= '<BR>'.join(s)
        return s
    def myrows(self):
        import mytags as Tag
        p= [x.p for x in self.xs]
        p= sorted(set(p))
        for x in p:
            for v in x.img:
                yield v.myrow()
        s4= '%s' % self
        c4= 'c s2em fTNR bgReadingOrange'
        s5= self.mydate()
        c5= 'c s2em fVerdana'
        def f(x, c):
            x= Tag.Td(x)
            x.c= c
            return x
        s4= f(s4,c4)
        s5= f(s5,c5)
        yield Tag.Tr([s4,s5])


